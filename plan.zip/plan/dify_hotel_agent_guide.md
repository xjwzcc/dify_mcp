# 基于 Dify 平台搭建酒店智能客服 Agent 完整实施指南

## 一、Dify 平台架构选型

### 1.1 应用类型选择

Dify 提供多种应用类型，针对酒店智能客服场景的推荐方案：

```
┌─────────────────────────────────────────────────────────────┐
│                    Dify 应用架构                              │
│                                                              │
│   主应用：Chatflow（对话型工作流）                              │
│   ├── 适合多轮对话 + 复杂业务逻辑                              │
│   ├── 支持条件分支、工具调用、变量传递                          │
│   └── 内置对话记忆管理                                        │
│                                                              │
│   辅助应用：Workflow（独立工作流，被主应用调用）                  │
│   ├── 订单查询工作流                                          │
│   ├── 房态价格查询工作流                                      │
│   └── 工单创建工作流                                          │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 模型配置建议

| 用途 | 推荐模型 | 说明 |
|---|---|---|
| 主对话模型 | GPT-4o / Claude 3.5 Sonnet | 主力推理，多轮对话质量高 |
| 意图分类 | GPT-4o-mini / Claude 3 Haiku | 轻量快速，降低延迟和成本 |
| 向量嵌入 | text-embedding-3-small | 知识库检索用 |
| 语音转文字 | Whisper | 如需语音接入 |

---

## 二、知识库搭建（Knowledge Base）

### 2.1 知识库创建步骤

在 Dify 控制台中创建以下知识库：

#### 知识库 1：酒店基础信息（hotel-basic-info）

**索引模式**：高质量（High Quality）
**分块策略**：自动分段 + 清洗
**检索模式**：混合检索（Hybrid Search）

需要录入的文档：

```
文档清单：
├── 01-酒店概况.md          （基本信息、开业时间、品牌介绍）
├── 02-房型信息.md          （所有房型详情、价格区间、设施）
├── 03-餐饮服务.md          （早餐、餐厅、客房送餐）
├── 04-酒店设施.md          （健身房、儿童乐园、洗衣房、停车场）
├── 05-交通指引.md          （地铁、打车、自驾、机场大巴）
└── 06-联系方式.md          （前台电话、预订部、投诉热线）
```

#### 知识库 2：政策规则（hotel-policies）

```
文档清单：
├── 01-入住退房政策.md      （入住时间、退房时间、延迟退房）
├── 02-预订取消政策.md      （各渠道取消规则、退款政策）
├── 03-儿童政策.md          （加床、早餐、乐园使用规则）
├── 04-宠物政策.md          （是否允许、收费标准）
├── 05-会员权益.md          （等级、积分、专属服务）
└── 06-特殊政策.md          （节假日、大促期间特别规定）
```

#### 知识库 3：体验与推荐（hotel-experience）

```
文档清单：
├── 01-汉服体验.md          （预约方式、款式、拍照攻略）
├── 02-周边景点.md          （老门东、夫子庙、秦淮河等）
├── 03-美食推荐.md          （酒店餐厅 + 周边小吃 + 网红店）
├── 04-文化故事.md          （老门东历史、秦淮文化）
├── 05-亲子攻略.md          （儿童乐园、亲子活动、亲子路线）
└── 06-季节推荐.md          （春夏秋冬不同玩法）
```

### 2.2 知识库文档示例

以下是需要录入知识库的文档内容示例：

---

#### 文档：房型信息.md

```markdown
# 南京老门东金陵文璟酒店 - 房型信息

## 一、高级大床房
- **面积**：约30㎡
- **床型**：1.8m大床
- **楼层**：2-4层
- **景观**：部分房间可观庭院景观
- **设施**：智能客控系统、55寸智能电视、独立卫浴、雨淋花洒、品牌洗浴用品、迷你吧、保险箱、免费WiFi
- **价格区间**：¥500-800/晚（随季节浮动）
- **适合人群**：商务出差、情侣
- **含早情况**：可选含早/不含早

## 二、豪华双床房
- **面积**：约35㎡
- **床型**：2张1.2m单人床
- **楼层**：2-4层
- **景观**：庭院景观或城市景观
- **设施**：同高级大床房
- **价格区间**：¥600-900/晚
- **适合人群**：亲子家庭、朋友同行
- **含早情况**：可选含早/不含早

## 三、亲子主题房
- **面积**：约40㎡
- **床型**：1.8m大床 + 儿童床
- **楼层**：2-3层（安全考虑低楼层）
- **特色**：卡通主题装饰、儿童洗漱用品、儿童拖鞋浴袍
- **附加权益**：免费使用儿童乐园、赠送儿童欢迎礼包
- **价格区间**：¥800-1200/晚
- **适合人群**：亲子家庭
- **含早情况**：含双早，1.2m以下儿童早餐免费

## 四、复式Loft房
- **面积**：约50㎡（上下两层）
- **床型**：上层1.8m大床，下层休闲区可加床
- **楼层**：特殊楼层
- **景观**：部分园景Loft可观苏州园林式庭院
- **特色**：复式设计，空间感强，下层客厅+上层卧室
- **价格区间**：¥1000-1500/晚
- **适合人群**：家庭、情侣、追求空间感的客人
- **含早情况**：含双早
- **住客评价**："像住在画里""空间超大很惊喜"

## 五、园景套房
- **面积**：约60㎡
- **床型**：1.8m大床
- **楼层**：高层
- **景观**：正对庭院园林，"有着苏州园林一样的典雅别致"
- **特色**：独立客厅、观景阳台、管家专属服务
- **价格区间**：¥1500-2500/晚
- **适合人群**：蜜月、高端商务、追求品质的客人
- **含早情况**：含双早 + 下午茶
- **附加权益**：免费迷你吧、优先安排汉服体验

## 通用说明
- 所有房型均配备智能客控系统，支持手机/语音控制灯光、窗帘、空调
- 所有房型免费WiFi，速度≥100Mbps
- 加床服务：¥200/晚（含早），需提前预约
- 婴儿床免费提供，需提前1天预约
```

---

#### 文档：入住退房政策.md

```markdown
# 入住与退房政策

## 入住时间
- **标准入住时间**：14:00
- **提前入住**：视当日房态，可尝试申请提前至12:00入住，不额外收费
- **最早入住**：如需12:00前入住，需加收半天房费
- **办理入住所需证件**：身份证（中国大陆）/ 护照（外籍）/ 港澳通行证
- **押金**：¥500/间（支持信用卡预授权或现金）

## 退房时间
- **标准退房时间**：12:00
- **延迟退房**：
  - 12:00-14:00：免费（需提前申请，视房态）
  - 14:00-18:00：加收半天房费
  - 18:00后：加收全天房费
- **会员延迟退房**：金卡及以上会员可享14:00免费延迟退房

## 取消政策
- **免费取消**：入住日前1天18:00前可免费取消
- **逾期取消**：入住日前1天18:00后取消，收取首晚房费
- **未入住（No Show）**：收取首晚全额房费
- **OTA渠道**：以各平台预订时显示的取消政策为准
- **不可取消订单**：特价房/促销房通常不可取消，预订时请确认

## 儿童政策
- **12岁以下儿童**：与成人同住不加收费用（使用现有床铺）
- **1.2m以下儿童**：早餐免费
- **1.2m以上儿童**：早餐按成人半价收费
- **加床**：¥200/晚（含一份早餐）
- **婴儿床**：免费提供（限1张/间，需提前预约）

## 宠物政策
- 本酒店暂不接受宠物入住
- 导盲犬除外（需提供相关证明）

## 特殊说明
- 酒店支持24小时前台服务
- 行李寄存：退房后可免费寄存行李至当日20:00
- 发票：支持电子发票，退房时前台开具或退房后邮件申请
```

---

#### 文档：汉服体验.md

```markdown
# 汉服体验服务

## 服务概述
南京老门东金陵文璟酒店提供免费汉服体验服务，住客可在酒店内及周边老门东街区穿着汉服拍照打卡，感受传统文化魅力。

## 体验详情
- **费用**：住客免费（非住客¥99/次）
- **体验时间**：每日 09:00-20:00
- **领取地点**：酒店一楼前台
- **归还时间**：当日20:00前归还

## 汉服款式
- **女款**：齐胸襦裙、明制汉服、宋制褙子等，约20+款式可选
- **男款**：直裰、圆领袍等，约10+款式可选
- **儿童款**：男女儿童各5+款式，适合3-12岁
- **配饰**：提供头饰、扇子、油纸伞等搭配道具

## 推荐拍照地点
1. **酒店内庭院**：月洞门前（最出片！光线最佳时间14:00-16:00）
2. **酒店回廊**：古色古香的长廊，适合拍古风意境照
3. **老门东街区**：步行5分钟，明清建筑群，随手一拍都是大片
4. **箍桶巷**：老门东内的特色巷子，青砖黛瓦背景绝佳
5. **边营街**：酒店门口的历史街道，复古感十足

## 温馨提示
- 建议下午时段体验，光线最柔和
- 周末和节假日汉服较抢手，建议入住后尽早领取
- 酒店提供简单妆发服务（收费¥50/次，需提前预约）
- 穿汉服在老门东很常见，无需害羞，融入感很强
- 如需专业跟拍摄影师，前台可协助推荐（费用自理）
```

---

### 2.3 知识库检索配置

在 Dify 知识库设置中：

```yaml
# 检索设置
retrieval_mode: hybrid          # 混合检索
top_k: 5                        # 召回Top-5
score_threshold: 0.5            # 相似度阈值
reranking_model: bge-reranker-v2  # 重排序模型

# 分块设置
chunk_size: 300                  # 每块300字
chunk_overlap: 50                # 重叠50字
separator: "\n##"                # 按二级标题分段
```

---

## 三、Chatflow 工作流编排

### 3.1 整体工作流架构

```
┌──────┐    ┌──────────┐    ┌──────────────┐    ┌──────────────┐
│ 开始  │───▶│ 变量聚合  │───▶│ 意图分类器    │───▶│ 条件分支      │
│(用户  │    │(提取对话  │    │(LLM分类)     │    │(路由到子流程) │
│ 输入) │    │ 上下文)   │    │              │    │              │
└──────┘    └──────────┘    └──────────────┘    └──────┬───────┘
                                                       │
                    ┌──────────────────────────────────┤
                    │              │              │     │          │
              ┌─────▼────┐  ┌─────▼────┐  ┌─────▼───┐│    ┌─────▼────┐
              │ 预订查询  │  │ 酒店咨询  │  │ 周边推荐 ││    │ 投诉处理  │
              │ 子流程    │  │ 子流程    │  │ 子流程   ││    │ 子流程    │
              └─────┬────┘  └─────┬────┘  └─────┬───┘│    └─────┬────┘
                    │              │              │     │          │
                    └──────────────┴──────────────┴────┴──────────┘
                                                       │
                                                ┌──────▼──────┐
                                                │   回复整合    │
                                                │  (LLM节点)   │
                                                └──────┬──────┘
                                                       │
                                                ┌──────▼──────┐
                                                │    结束      │
                                                │  (输出回复)   │
                                                └─────────────┘
```

### 3.2 Dify DSL 配置详解

#### 节点 1：开始节点（Start）

```yaml
node_type: start
variables:
  - name: sys.query          # 用户输入
    type: string
  - name: sys.conversation_id  # 会话ID
    type: string
  - name: sys.user_id        # 用户ID（用于画像关联）
    type: string
```

#### 节点 2：意图分类器（Question Classifier）

```yaml
node_type: question-classifier
model:
  provider: openai
  name: gpt-4o-mini          # 用轻量模型分类，降低延迟
  temperature: 0
classes:
  - id: booking
    name: "预订相关"
    description: "用户询问房型、价格、预订、修改订单、取消订单等"
  - id: inquiry
    name: "酒店咨询"
    description: "用户咨询酒店设施、入住退房政策、交通指引、WiFi、停车等"
  - id: recommendation
    name: "周边推荐"
    description: "用户询问周边景点、美食、行程规划、游玩攻略等"
  - id: experience
    name: "特色体验"
    description: "用户询问汉服体验、管家服务、接送机、客房服务等"
  - id: complaint
    name: "投诉反馈"
    description: "用户表达不满、投诉问题、要求赔偿、负面情绪明显"
  - id: general
    name: "闲聊寒暄"
    description: "打招呼、感谢、告别等非业务性对话"
instruction: |
  你是一个酒店客服意图分类器。请根据用户的输入内容，判断其属于哪个类别。
  注意：
  1. 如果用户语气中包含明显不满或愤怒情绪，优先分类为"投诉反馈"
  2. 如果用户同时涉及多个意图，选择最主要的一个
  3. "预订相关"包括查价格、查房型、预订、改订、取消等所有与订单相关的操作
  4. "酒店咨询"是关于酒店本身的信息，"周边推荐"是关于酒店周边的信息
```

#### 节点 3：条件分支（IF/ELSE Router）

```yaml
node_type: if-else
conditions:
  - case: "{{intent_class}} == 'booking'"
    goto: booking_flow
  - case: "{{intent_class}} == 'inquiry'"
    goto: inquiry_flow
  - case: "{{intent_class}} == 'recommendation'"
    goto: recommendation_flow
  - case: "{{intent_class}} == 'experience'"
    goto: experience_flow
  - case: "{{intent_class}} == 'complaint'"
    goto: complaint_flow
  - default:
    goto: general_flow
```

---

### 3.3 各子流程详细设计

#### 子流程 A：酒店咨询流程（inquiry_flow）

```yaml
# 节点 A1：知识库检索
node_type: knowledge-retrieval
knowledge_bases:
  - hotel-basic-info       # 搜索基础信息库
  - hotel-policies         # 搜索政策规则库
query: "{{sys.query}}"
retrieval_mode: hybrid
top_k: 5
score_threshold: 0.5
reranking_enabled: true

# 节点 A2：LLM 回答生成
node_type: llm
model:
  provider: openai
  name: gpt-4o
  temperature: 0.3
  max_tokens: 1000
context:
  - "{{knowledge_retrieval.result}}"
prompt: |
  ## 角色
  你是南京老门东金陵文璟酒店的AI管家"文璟小助手"。

  ## 检索到的知识
  {{knowledge_retrieval.result}}

  ## 对话历史
  {{sys.conversation_history}}

  ## 用户问题
  {{sys.query}}

  ## 回答要求
  1. 基于检索到的知识回答，不可编造信息
  2. 如果知识库中没有相关信息，诚实告知并提供前台电话：025-XXXXXXXX
  3. 回答要简洁友好，像朋友聊天一样自然
  4. 政策类回答结尾加"温馨提示"，补充相关注意事项
  5. 适当使用emoji增加亲和力，但不过度
  6. 如果用户问题涉及实时信息（如当日房价），提示其咨询前台获取最新信息
  7. 回答后预判用户可能的下一个问题，主动提供相关信息

  ## 回答格式
  直接回答用户问题，不要说"根据知识库..."这样的话。
```

#### 子流程 B：预订查询流程（booking_flow）

```yaml
# 节点 B1：槽位提取（LLM）
node_type: llm
model:
  provider: openai
  name: gpt-4o-mini
  temperature: 0
prompt: |
  从用户的对话中提取预订相关信息，以JSON格式输出：

  对话历史：{{sys.conversation_history}}
  当前输入：{{sys.query}}

  请提取以下字段（如未提及则填null）：
  {
    "check_in_date": "入住日期，格式YYYY-MM-DD",
    "check_out_date": "离店日期，格式YYYY-MM-DD",
    "nights": "入住天数",
    "room_type": "房型偏好：大床房/双床房/亲子房/Loft房/套房",
    "guest_count": "入住人数",
    "has_children": "是否带儿童 true/false",
    "children_age": "儿童年龄",
    "budget": "预算范围",
    "special_request": "特殊需求",
    "action": "用户意图：query_room(查询房型)/query_price(查价格)/book(预订)/modify(修改)/cancel(取消)"
  }

  注意：
  - 今天是 {{sys.current_date}}
  - "下周末"指本周六日，"明天"指明天的日期
  - 如果用户说"住两晚"，根据入住日期推算离店日期
  - 只提取用户明确说过的信息，不要推测

# 节点 B2：条件判断 - 信息是否完整
node_type: if-else
conditions:
  - case: "槽位信息完整（有日期+房型偏好）"
    goto: B3_query_rooms
  - default:
    goto: B4_ask_missing_info

# 节点 B3：知识库检索房型信息
node_type: knowledge-retrieval
knowledge_bases:
  - hotel-basic-info
query: "{{extracted_room_type}} 房型 价格 设施"
top_k: 3

# 节点 B4：追问缺失信息（LLM）
node_type: llm
prompt: |
  用户想要预订酒店，但以下信息还缺失：
  {{missing_slots}}

  请用亲切的语气追问缺失信息。
  要求：
  - 不要一次追问太多，优先问最关键的（日期 > 人数 > 房型）
  - 如果能根据上下文推断，主动给出建议
  - 例如用户说"带孩子"，主动推荐亲子主题房和Loft房

# 节点 B5：生成预订推荐回复（LLM）
node_type: llm
model:
  provider: openai
  name: gpt-4o
  temperature: 0.5
prompt: |
  ## 角色
  你是酒店AI管家，正在帮用户选择合适的房型。

  ## 用户需求
  {{extracted_slots}}

  ## 可选房型信息
  {{knowledge_retrieval.result}}

  ## 回答要求
  1. 根据用户需求推荐最合适的1-3个房型
  2. 每个房型列出：名称、价格、面积、核心卖点
  3. 如果用户带孩子，优先推荐亲子主题房或Loft房
  4. 如果是情侣/蜜月，优先推荐园景套房或Loft房
  5. 主动提醒相关权益（如含早、儿童免费早餐等）
  6. 结尾询问用户选择，引导下一步
  7. 使用清晰的编号列表格式

  ## 示例格式
  为您推荐以下房型 🏨

  1️⃣ **亲子主题房** - ¥XXX/晚
     📐 40㎡ | 🛏 大床+儿童床
     ✨ 卡通主题 + 免费儿童乐园 + 儿童欢迎礼包
     🥣 含双早，1.2m以下儿童免费

  2️⃣ **复式Loft家庭房** - ¥XXX/晚
     📐 50㎡ | 🛏 上层大床+下层客厅
     ✨ 复式空间超大 + 部分园景
     🥣 含双早

  您更倾向哪种呢？需要我帮您锁定房间吗？
```

#### 子流程 C：周边推荐流程（recommendation_flow）

```yaml
# 节点 C1：知识库检索
node_type: knowledge-retrieval
knowledge_bases:
  - hotel-experience
query: "{{sys.query}}"
top_k: 5

# 节点 C2：生成推荐回复（LLM）
node_type: llm
model:
  provider: openai
  name: gpt-4o
  temperature: 0.7         # 推荐类内容温度略高，更有创意
prompt: |
  ## 角色
  你是一位熟悉南京的旅行达人，同时也是金陵文璟酒店的AI管家。

  ## 参考信息
  {{knowledge_retrieval.result}}

  ## 对话历史
  {{sys.conversation_history}}

  ## 用户问题
  {{sys.query}}

  ## 回答要求
  1. 推荐要有温度，像朋友聊天一样分享
  2. 结合酒店地理位置（老门东核心区），给出步行/车程时间
  3. 如果能关联酒店服务（如汉服体验），自然带出
  4. 根据季节（当前{{sys.current_date}}）给出应季建议
  5. 亲子/情侣/老人不同客群给出差异化建议
  6. 包含实用信息：营业时间、价格、注意事项
  7. 使用emoji和清晰的格式，增强阅读体验

  ## 注意
  - 推荐的地点必须是真实存在的
  - 如果不确定某个地点的最新信息，标注"建议出发前确认"
  - 不要推荐与酒店竞争的住宿
```

#### 子流程 D：特色体验流程（experience_flow）

```yaml
# 节点 D1：知识库检索
node_type: knowledge-retrieval
knowledge_bases:
  - hotel-experience
  - hotel-basic-info
query: "{{sys.query}} 体验 服务 预约"
top_k: 5

# 节点 D2：生成回复（LLM）
node_type: llm
model:
  provider: openai
  name: gpt-4o
  temperature: 0.5
prompt: |
  ## 角色
  你是金陵文璟酒店的AI礼宾管家。

  ## 参考信息
  {{knowledge_retrieval.result}}

  ## 用户问题
  {{sys.query}}

  ## 回答要求
  1. 详细介绍服务内容、预约方式、费用
  2. 主动给出实用Tips（最佳体验时间、注意事项等）
  3. 如果是汉服体验，推荐拍照地点和最佳时间
  4. 如果需要预约/安排，告知用户如何操作
  5. 关联推荐其他体验服务
  
  ## 需要人工处理的服务
  以下服务需提示用户联系前台：
  - 接送机安排
  - 生日/纪念日布置
  - 大型团队活动
  回复中提供前台电话：025-XXXXXXXX
```

#### 子流程 E：投诉处理流程（complaint_flow）

```yaml
# 节点 E1：情绪分析（LLM）
node_type: llm
model:
  provider: openai
  name: gpt-4o-mini
  temperature: 0
prompt: |
  分析用户的情绪等级和投诉内容，以JSON格式输出：

  用户输入：{{sys.query}}
  对话历史：{{sys.conversation_history}}

  {
    "emotion_level": "mild(轻度不满) / moderate(中度不满) / severe(强烈愤怒)",
    "complaint_category": "房间问题/服务问题/设施问题/价格问题/其他",
    "complaint_detail": "投诉的具体内容摘要",
    "needs_human": true/false,
    "urgency": "low/medium/high"
  }

  判断规则：
  - 包含"退款""赔偿""曝光""投诉""差评"等关键词 → severe
  - 包含"不满意""不开心""有问题"等 → moderate
  - 包含"希望改善""建议""有点..."等 → mild
  - severe 级别或涉及退款/安全 → needs_human = true

# 节点 E2：条件分支
node_type: if-else
conditions:
  - case: "emotion_level == 'severe' || needs_human == true"
    goto: E3_transfer_human
  - default:
    goto: E4_ai_handle

# 节点 E3：转人工（严重投诉）
node_type: llm
prompt: |
  用户情绪激动，需要转接人工。请生成一段安抚性回复：

  投诉内容：{{complaint_detail}}

  回复模板：
  "非常抱歉给您带来了不好的体验，我完全理解您的心情 😔
   您反映的[问题]我已经详细记录，现在为您转接专属客服经理，
   他/她会在3分钟内联系您，为您妥善处理。
   您也可以直接拨打服务热线：025-XXXXXXXX（24小时）
   再次向您致歉，我们一定会给您一个满意的答复。"

# 节点 E4：AI处理（轻中度）
node_type: llm
model:
  provider: openai
  name: gpt-4o
  temperature: 0.3
prompt: |
  ## 角色
  你是酒店AI客服，正在处理一位客人的投诉。

  ## 投诉信息
  - 情绪等级：{{emotion_level}}
  - 投诉类别：{{complaint_category}}
  - 具体内容：{{complaint_detail}}

  ## 回复要求
  1. 第一句必须表达真诚歉意和共情
  2. 确认已记录问题
  3. 给出具体的解决方案或行动承诺
  4. 如果能立即解决（如客房服务），告知处理时间
  5. 如果不能立即解决，承诺跟进并给出时间节点
  6. 语气要诚恳温暖，避免公式化回复
  7. 结尾关心用户其他需求

  ## 禁止
  - 不可推卸责任或辩解
  - 不可承诺无法兑现的补偿
  - 不可暴露内部管理问题
```

#### 子流程 F：闲聊寒暄（general_flow）

```yaml
node_type: llm
model:
  provider: openai
  name: gpt-4o
  temperature: 0.7
prompt: |
  ## 角色
  你是金陵文璟酒店的AI管家"文璟小助手"，正在与客人闲聊。

  ## 用户输入
  {{sys.query}}

  ## 回答要求
  1. 保持友好亲切的语气
  2. 自然地将对话引导到酒店服务上
  3. 如果是打招呼，回复后主动介绍可以提供的帮助
  4. 如果是感谢/告别，表达祝福
  5. 可以适当穿插南京文化小知识，增加趣味性

  ## 示例
  用户："你好"
  回复："您好呀！欢迎来到金陵文璟酒店 🏮 
        我是您的AI管家小璟，随时为您服务。
        您可以问我关于房型预订、酒店设施、汉服体验、
        周边美食景点等任何问题哦~ 有什么可以帮您的？"
```

---

## 四、外部工具集成（HTTP Request / API Tools）

### 4.1 Dify 自定义工具配置

在 Dify 中通过「工具」模块配置以下 API 工具：

#### 工具 1：实时房态查询

```yaml
tool_name: query_room_availability
description: "查询酒店指定日期的可用房型和实时价格"
api_endpoint: "https://your-hotel-api.com/v1/rooms/availability"
method: POST
headers:
  Authorization: "Bearer {{api_key}}"
  Content-Type: "application/json"
request_body:
  hotel_id: "116717250"
  check_in: "{{check_in_date}}"      # 从槽位提取
  check_out: "{{check_out_date}}"
  adults: "{{guest_count}}"
  children: "{{children_count}}"
response_mapping:
  rooms: "data.available_rooms"
  min_price: "data.min_price"
```

#### 工具 2：创建预订订单

```yaml
tool_name: create_reservation
description: "为用户创建酒店预订订单"
api_endpoint: "https://your-hotel-api.com/v1/reservations"
method: POST
request_body:
  hotel_id: "116717250"
  room_type: "{{room_type}}"
  check_in: "{{check_in_date}}"
  check_out: "{{check_out_date}}"
  guest_name: "{{guest_name}}"
  phone: "{{phone}}"
  special_requests: "{{special_request}}"
```

#### 工具 3：创建服务工单

```yaml
tool_name: create_service_ticket
description: "创建客房服务或投诉工单，通知酒店工作人员处理"
api_endpoint: "https://your-hotel-api.com/v1/tickets"
method: POST
request_body:
  type: "{{ticket_type}}"           # complaint / service_request
  priority: "{{urgency}}"           # low / medium / high
  category: "{{complaint_category}}"
  description: "{{complaint_detail}}"
  room_number: "{{room_number}}"
  conversation_summary: "{{conversation_summary}}"
```

#### 工具 4：天气查询

```yaml
tool_name: get_weather
description: "查询南京未来几天的天气预报，为用户行程提供参考"
api_endpoint: "https://api.weatherapi.com/v1/forecast.json"
method: GET
params:
  key: "{{weather_api_key}}"
  q: "Nanjing"
  days: 3
  lang: "zh"
```

### 4.2 工具在工作流中的调用方式

```yaml
# 在预订流程中调用房态查询工具
node_type: tool
tool_name: query_room_availability
inputs:
  check_in_date: "{{B1_extracted.check_in_date}}"
  check_out_date: "{{B1_extracted.check_out_date}}"
  guest_count: "{{B1_extracted.guest_count}}"
output_variable: available_rooms

# 将工具返回结果传给LLM生成推荐
node_type: llm
context:
  - "{{available_rooms}}"
  - "{{knowledge_retrieval.result}}"
```

---

## 五、对话记忆与变量管理

### 5.1 会话变量配置

在 Chatflow 中设置以下会话变量（Conversation Variables），跨轮次保持：

```yaml
conversation_variables:
  # 用户信息
  - name: user_type
    type: string
    description: "用户类型：new/returning/vip"
    default: "new"

  - name: user_persona
    type: string
    description: "用户画像：family/couple/business/culture"
    default: ""

  # 预订上下文
  - name: booking_context
    type: object
    description: "预订槽位信息，跨轮次积累"
    default: {}

  # 情绪追踪
  - name: emotion_trend
    type: string
    description: "情绪趋势：positive/neutral/negative"
    default: "neutral"

  # 推荐历史
  - name: recommended_rooms
    type: array
    description: "已推荐过的房型，避免重复推荐"
    default: []

  # 问题解决状态
  - name: issue_resolved
    type: boolean
    description: "当前问题是否已解决"
    default: false
```

### 5.2 上下文窗口策略

```yaml
memory:
  window_size: 10              # 保留最近10轮对话
  strategy: "token_limit"      # 按Token限制
  max_tokens: 4000             # 最多4000 Token的历史
  summary_enabled: true        # 超出时自动摘要
```

---

## 六、Dify 实操搭建步骤（Step by Step）

### Step 1：环境准备

```
1. 登录 Dify 平台（cloud.dify.ai 或自部署版本）
2. 进入「设置」→「模型供应商」，配置：
   - OpenAI API Key（GPT-4o + GPT-4o-mini）
   - 或其他模型供应商
3. 确认向量模型（Embedding Model）已配置
```

### Step 2：创建知识库

```
1. 进入「知识库」→「创建知识库」
2. 创建3个知识库：
   a. hotel-basic-info（酒店基础信息）
   b. hotel-policies（政策规则）
   c. hotel-experience（体验推荐）
3. 每个知识库上传对应的Markdown文档
4. 配置索引模式：
   - 索引方式：高质量
   - 分段设置：自动 / 300字
   - 检索模式：混合检索
   - Rerank 模型：开启
```

### Step 3：创建 Chatflow 应用

```
1. 进入「工作室」→「创建应用」→ 选择「Chatflow」
2. 应用名称：金陵文璟酒店智能客服
3. 描述：基于AI的酒店全场景智能客服系统
```

### Step 4：搭建工作流节点

```
按照第三章的架构，依次添加以下节点：

1. 开始节点（自动生成）
2. 问题分类器节点（Question Classifier）
   - 配置6个分类及描述
   - 选择 GPT-4o-mini 作为分类模型
3. 为每个分类创建对应的处理分支：
   a. 知识检索节点（Knowledge Retrieval）→ 关联对应知识库
   b. LLM节点 → 配置System Prompt和Context
   c. 条件分支节点（如需要）
4. 结束节点 → 输出最终回复
```

### Step 5：配置工具

```
1. 进入「工具」→「自定义工具」
2. 添加 API 工具（如天气查询、房态查询等）
3. 或使用 Dify 内置工具（如 Google 搜索）
4. 在工作流中的 LLM 节点关联工具
```

### Step 6：配置应用特性

```
1. 开场白设置：
   "您好！欢迎来到金陵文璟酒店 🏮 我是AI管家小璟~
    我可以帮您：
    🏨 查询房型与预订
    📋 了解酒店设施与政策
    👘 预约汉服体验
    🗺 推荐周边美食景点
    请问有什么可以帮您的？"

2. 推荐问题：
   - "有什么房型推荐？"
   - "酒店提供免费停车吗？"
   - "怎么预约汉服体验？"
   - "带孩子周边有什么好玩的？"
   - "从南京南站怎么到酒店？"

3. 语音功能：开启（如需要）
4. 引用标注：开启（展示知识来源）
5. 内容审核：开启（过滤敏感内容）
```

### Step 7：测试与调试

```
1. 使用 Dify 内置的「调试与预览」功能
2. 准备测试用例集（见下方）
3. 逐一测试每个意图分支
4. 检查知识检索的召回质量
5. 验证多轮对话的上下文保持
6. 测试边缘情况（模糊意图、多意图等）
```

### Step 8：发布与集成

```
1. 发布应用，获取 API 接口
2. 集成方式：
   a. 网页嵌入（iframe / js-sdk）→ 嵌入官网
   b. API 接入 → 对接微信小程序 / APP
   c. Dify WebApp → 直接使用 Dify 提供的网页端
3. 配置访问控制和限流
```

---

## 七、测试用例集

### 7.1 功能测试用例

| 编号 | 测试场景 | 用户输入 | 期望行为 |
|---|---|---|---|
| T01 | 基础问答 | "酒店几点入住？" | 回答14:00，提及提前入住政策 |
| T02 | 房型查询 | "有什么房间推荐？" | 追问需求（日期/人数）后推荐 |
| T03 | 带条件查询 | "带两个孩子住，有家庭房吗？" | 推荐亲子房和Loft房 |
| T04 | 价格查询 | "Loft房多少钱一晚？" | 给出价格区间¥1000-1500 |
| T05 | 多轮预订 | "下周末带孩子住两晚" → "Loft房" → "订吧" | 完整槽位填充→确认→生成订单 |
| T06 | 汉服体验 | "汉服怎么预约？" | 详细说明流程+推荐拍照地点 |
| T07 | 交通指引 | "从禄口机场怎么过去？" | 给出打车/地铁方案 |
| T08 | 周边推荐 | "附近有什么好吃的？" | 推荐老门东周边美食 |
| T09 | 行程规划 | "两天怎么安排？" | 生成完整两日行程 |
| T10 | 轻度投诉 | "房间有点吵" | 道歉+解决方案 |
| T11 | 严重投诉 | "太差了，我要退款！" | 安抚+立即转人工 |
| T12 | 政策咨询 | "能带宠物吗？" | 明确回答不可+导盲犬除外 |
| T13 | 延迟退房 | "能晚点退房吗？" | 说明免费/收费政策 |
| T14 | 闲聊 | "你好" | 友好问候+介绍服务 |
| T15 | 模糊意图 | "嗯..." | 引导用户表达需求 |

### 7.2 边缘情况测试

| 编号 | 场景 | 用户输入 | 期望 |
|---|---|---|---|
| E01 | 非酒店问题 | "帮我写一篇作文" | 礼貌拒绝并引导 |
| E02 | 竞品比较 | "你们比旁边那家好在哪？" | 不贬低竞品，介绍自身优势 |
| E03 | 敏感话题 | "南京大屠杀..." | 尊重历史，引导回酒店话题 |
| E04 | 多意图混合 | "想订房，顺便问下有停车场吗" | 同时回答两个问题 |
| E05 | 方言/错别字 | "酒点有没得早饭吃" | 正确理解并回答 |

---

## 八、持续优化策略

### 8.1 数据监控看板

在 Dify 的「日志与标注」中监控：

| 监控指标 | 工具 | 频率 |
|---|---|---|
| 对话量/日 | Dify 后台统计 | 每日 |
| 意图分类准确率 | 人工抽检 | 每周 |
| 知识库召回质量 | 检查检索命中率 | 每周 |
| 用户满意度 | 对话结束评分 | 实时 |
| 人工转接率 | 统计转人工次数 | 每周 |
| Top未解决问题 | 分析低分对话 | 每周 |

### 8.2 迭代优化流程

```
每周：
1. 从 Dify 日志中导出低评分对话（≤3分）
2. 分析失败原因：
   a. 意图分类错误 → 优化分类器Prompt/增加示例
   b. 知识库未命中 → 补充知识文档/优化分块
   c. 回复不准确 → 修正知识库内容
   d. 回复不友好 → 优化LLM Prompt
3. 标注优质对话作为Few-shot示例
4. 更新知识库（新政策、价格变化、新活动）
5. 发布新版本并A/B测试

每月：
1. 分析高频问题Top 50，检查覆盖率
2. 收集酒店前台反馈，发现新需求
3. 评估整体KPI达成情况
4. 模型版本评估（是否升级基座模型）
```

### 8.3 标注与优化

利用 Dify 的「标注回复」功能：

```
1. 进入「日志与标注」
2. 找到回复不理想的对话
3. 点击「改进」，标注正确的回复
4. 积累标注数据用于：
   a. 优化Prompt中的Few-shot示例
   b. 微调意图分类器
   c. 补充知识库盲区
```

---

## 九、部署架构建议

### 9.1 生产环境部署

```
┌─────────────────────────────────────────┐
│              负载均衡（Nginx）              │
└────────────────────┬────────────────────┘
                     │
┌────────────────────▼────────────────────┐
│          Dify 应用服务（Docker）           │
│  ┌──────────┐  ┌──────────┐             │
│  │ API 服务  │  │ Worker   │             │
│  │ (x2实例)  │  │ (x2实例)  │             │
│  └──────────┘  └──────────┘             │
└────────────────────┬────────────────────┘
                     │
     ┌───────────────┼───────────────┐
     │               │               │
┌────▼────┐   ┌──────▼──────┐  ┌─────▼─────┐
│ PostgreSQL│   │ Redis       │  │ Weaviate  │
│ (数据存储) │   │ (缓存/队列)  │  │ (向量存储) │
└──────────┘   └─────────────┘  └───────────┘
```

### 9.2 性能优化

| 优化项 | 措施 | 预期效果 |
|---|---|---|
| 响应延迟 | 意图分类用轻量模型(mini) | 分类<500ms |
| 知识检索 | 开启Rerank + 缓存热门问题 | 检索<200ms |
| 并发能力 | API服务2+实例 | 支持100并发 |
| 成本控制 | 简单问题用mini，复杂问题用4o | 成本降低40% |

---

## 十、总结 Checklist

搭建完成后的自检清单：

- [ ] 知识库：3个知识库已创建并导入文档
- [ ] 知识库：检索模式设为混合检索，Rerank已开启
- [ ] 工作流：意图分类器已配置6个分类
- [ ] 工作流：每个分支的LLM Prompt已优化
- [ ] 工作流：投诉分支包含情绪检测和转人工逻辑
- [ ] 工具：API工具已配置并测试通过
- [ ] 变量：会话变量已配置（预订上下文、情绪等）
- [ ] 开场白：已设置欢迎语和推荐问题
- [ ] 测试：15个功能测试用例全部通过
- [ ] 测试：5个边缘情况测试全部通过
- [ ] 发布：API接口已生成，可供前端集成
- [ ] 监控：日志与标注功能已开启
